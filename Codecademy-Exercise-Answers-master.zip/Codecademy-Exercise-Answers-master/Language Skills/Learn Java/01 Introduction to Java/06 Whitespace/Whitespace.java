public class WhiteSpace {
	public static void main(String[] args) {

		boolean isFormatted = false;System.out.println(isFormatted);
		System.out.println(isFormatted);
	}
}
