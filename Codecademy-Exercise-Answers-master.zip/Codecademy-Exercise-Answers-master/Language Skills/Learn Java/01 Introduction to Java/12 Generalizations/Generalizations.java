public class Generalizations {
	public static void main(String[] args) {

		// comment
		boolean isComplete = true;
		int awesomeLevel = 121;
		int epicLevel = 2 * awesomeLevel;
		System.out.println(epicLevel);


	}
}
