public class IfElseIf {
	public static void main(String[] args) {

		int round = 1;

		if (round > 12) {

			System.out.println("The match is over!");

		} else if (round > 0) {

			System.out.println("The match is underway!");

		}	else {

			System.out.println("The boxing match hasn't started yet.");

		}
	}
}
