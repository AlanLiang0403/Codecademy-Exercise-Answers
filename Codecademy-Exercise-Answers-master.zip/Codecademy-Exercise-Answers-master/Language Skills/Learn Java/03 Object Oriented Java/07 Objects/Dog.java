class Dog {
  int age;
	public Dog(int dogsAge){
    age = dogsAge;
  }
	public static void main(String[] args) {
    Dog spike = new Dog(4);
	}
}
