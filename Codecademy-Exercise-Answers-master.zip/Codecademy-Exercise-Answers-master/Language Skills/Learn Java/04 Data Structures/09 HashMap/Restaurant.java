import java.util.HashMap;

public class Restaurant {
	public static void main(String[] args) {

	HashMap<String, Integer> restaurantMenu = new HashMap<String, Integer>();

	}
}
