#Set spam equal to 1 using modulo on line 3!

spam = 3 % 2

print spam
