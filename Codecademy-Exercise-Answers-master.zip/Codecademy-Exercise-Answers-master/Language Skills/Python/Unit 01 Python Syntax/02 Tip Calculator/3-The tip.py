# You're almost there! Assign the tip variable on line 5.

meal = 44.50
tax = 0.0675
tip = 0.15
