# Reassign meal on line 7!

meal = 44.50
tax = 0.0675
tip = 0.15

meal = meal+ meal * tax
