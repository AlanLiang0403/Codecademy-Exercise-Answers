bool_one = False and False
print bool_one

bool_two = -(-(-(-2))) == -2 and 4 >= 16**0.5


bool_three = 19 % 4 != 300 / 10 / 10 and False


bool_four = -(1**2) < 2**0 and 10 % 10 <= 20 - 10 * 2


bool_five = True and True
