# Set minimum to the min value of any set of numbers on line 3!

minimum = min(-1,30,3,78,-22)

print minimum
