# Print out the types of an integer, a float,
# and a string on separate lines below.

print type(3)
print type(2.1)
print type('no')
