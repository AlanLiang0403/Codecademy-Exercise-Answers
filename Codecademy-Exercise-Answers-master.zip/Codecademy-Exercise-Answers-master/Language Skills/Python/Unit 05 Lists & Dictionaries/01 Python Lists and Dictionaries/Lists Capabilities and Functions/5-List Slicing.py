suitcase = ["sunglasses", "hat", "passport", "laptop", "suit", "shoes"]

first  = suitcase[0:2]  # The first and second items (index zero and one)
print first
middle = suitcase[2:4]  # Third and fourth items (index two and three)
print middle
last   = suitcase[4:6]  # The last two items (index four and five)
