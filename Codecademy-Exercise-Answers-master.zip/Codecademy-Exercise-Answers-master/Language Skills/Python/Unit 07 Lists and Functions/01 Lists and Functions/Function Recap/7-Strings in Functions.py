n = "Hello"
# Your function here!
def string_function(s):
    return s + 'world'
print string_function(n)
