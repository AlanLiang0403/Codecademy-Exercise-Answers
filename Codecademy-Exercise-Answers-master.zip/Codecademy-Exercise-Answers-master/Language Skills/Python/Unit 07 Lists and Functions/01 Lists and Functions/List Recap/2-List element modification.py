n = [1, 3, 5]
# Do your multiplication here
n[1] = n[1] * 5
print n
