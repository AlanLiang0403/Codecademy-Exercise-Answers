#adicionar ao final as seguintes linhas:
    if turn == 3:
        print "Game Over"
