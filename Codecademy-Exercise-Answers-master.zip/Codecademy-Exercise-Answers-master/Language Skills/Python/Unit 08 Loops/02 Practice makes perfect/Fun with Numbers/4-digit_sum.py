def digit_sum(n):
        b = []
        n = str(n)
        for a in n:
                a = int(a)
                b.append(a)
        return sum(b)
        print sum(b)
