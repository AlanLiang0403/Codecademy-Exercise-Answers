threes_and_fives = [ x for x in range(1,16) if ((x%3==0) or (x%5==0))]
print threes_and_fives
