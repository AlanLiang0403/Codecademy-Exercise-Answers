a = 0b10111011
mask = 0b100
print bin(a | mask)
