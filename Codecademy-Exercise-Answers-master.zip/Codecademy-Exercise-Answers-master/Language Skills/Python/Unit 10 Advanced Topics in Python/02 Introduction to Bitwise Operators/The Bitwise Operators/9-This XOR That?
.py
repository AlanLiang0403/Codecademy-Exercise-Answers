print bin(0b1110 ^ 0b101)
