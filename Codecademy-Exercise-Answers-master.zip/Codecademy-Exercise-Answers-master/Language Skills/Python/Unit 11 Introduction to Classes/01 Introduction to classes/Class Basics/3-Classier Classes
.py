class Animal(object):
    def __init__(self):
        pass
