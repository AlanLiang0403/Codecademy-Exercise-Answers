class Car(object):
    pass
my_car = Car()
