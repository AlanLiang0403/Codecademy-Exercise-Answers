class Car(object):
    condition = "new"
my_car = Car()
print my_car.condition
