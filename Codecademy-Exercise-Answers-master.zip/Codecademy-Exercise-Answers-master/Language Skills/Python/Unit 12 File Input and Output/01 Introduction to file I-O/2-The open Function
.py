my_file = open("output.txt", "r+")
