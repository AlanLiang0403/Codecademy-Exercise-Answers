my_file = open("output.txt", "r")
print my_file.read()
my_file.close()
