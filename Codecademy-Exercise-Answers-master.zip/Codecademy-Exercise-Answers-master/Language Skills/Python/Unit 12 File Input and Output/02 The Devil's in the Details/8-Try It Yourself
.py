with open("text.txt", "w") as my_file:
	my_file.write("Tretas dos Bronzetas")
