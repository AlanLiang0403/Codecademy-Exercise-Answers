sum = 13 + 379
product = 923 * 15
quotient = 13209 / 17
