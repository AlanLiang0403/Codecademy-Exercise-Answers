# comment
=begin
comment
for
fun
=end
