print "What's your first name?"
first_name = gets.chomp
first_name.capitalize!

print "What's your last name?"
last_name = gets.chomp
last_name.capitalize!

print "What city are you from?"
 city = gets.chomp
 city.capitalize!
<<<<<<< HEAD
=======
<<<<<<< HEAD
 
 print "Enter the abbreviation of your state or province please."
 state = gets.chomp
 state.capitalize!
 
=======
>>>>>>> 61355021af394525dccc473eb8125a3566626a38

 print "Enter the abbreviation of your state or province please."
 state = gets.chomp
 state.capitalize!

<<<<<<< HEAD
=======
>>>>>>> Non Track and Ruby Track Updates
>>>>>>> 61355021af394525dccc473eb8125a3566626a38
