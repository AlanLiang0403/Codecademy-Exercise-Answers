if true
	print "hello"
end