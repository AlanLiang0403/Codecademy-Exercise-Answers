# test_1 should be false
test_1 = false ==true 

# test_2 = should be false
test_2 = false != false

# test_3 = should be true
test_3 = true && true && true