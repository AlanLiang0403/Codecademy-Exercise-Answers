for num in 1..15
    puts num
end