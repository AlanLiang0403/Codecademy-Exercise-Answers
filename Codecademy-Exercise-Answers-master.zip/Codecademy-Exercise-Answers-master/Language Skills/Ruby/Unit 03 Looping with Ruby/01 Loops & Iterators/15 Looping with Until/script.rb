i = 1
until i == 51 do
  print i
  i += 1
end
