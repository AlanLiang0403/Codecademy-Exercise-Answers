for i in 1..50
  print i
  i += 1
end
