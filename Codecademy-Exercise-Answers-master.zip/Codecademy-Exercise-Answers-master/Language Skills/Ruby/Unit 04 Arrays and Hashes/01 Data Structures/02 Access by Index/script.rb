demo_array = [100, 200, 300, 400, 500]

print  demo_array[2]
