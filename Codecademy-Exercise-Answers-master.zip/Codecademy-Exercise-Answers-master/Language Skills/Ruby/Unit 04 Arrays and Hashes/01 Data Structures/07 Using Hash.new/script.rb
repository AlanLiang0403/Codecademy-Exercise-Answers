pets = Hash.new
