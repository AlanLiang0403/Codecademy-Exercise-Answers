puts "input: "
text = gets.chomp
