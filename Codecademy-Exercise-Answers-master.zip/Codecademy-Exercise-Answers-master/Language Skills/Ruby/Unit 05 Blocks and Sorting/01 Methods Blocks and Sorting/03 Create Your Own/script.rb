# Define your method below!
def greeting
    puts "greetings mwre"
end




# Define your method above this line.

greeting # Ignore this for now. We'll explain
         # it in the next exercise!
